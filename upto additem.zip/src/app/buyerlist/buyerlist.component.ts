import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buyerlist',
  templateUrl: './buyerlist.component.html',
  styleUrls: ['./buyerlist.component.css']
})
export class BuyerlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
