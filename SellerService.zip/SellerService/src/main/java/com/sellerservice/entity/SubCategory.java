package com.sellerservice.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "sub_category")
public class SubCategory implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int subcategoryId;
	@Column
	private String subCategoryName;
	@ManyToOne
	@JoinColumn(name = "category_id_ref")
	private Category category;
	private String briefCategoryDetail;
	private Double gstPercentage;

	public SubCategory() {
		
	}

	public SubCategory(int subcategoryId, String subCategoryName, Category category, String briefCategoryDetail,
			Double gstPercentage) {
		super();
		this.subcategoryId = subcategoryId;
		this.subCategoryName = subCategoryName;
		this.category = category;
		this.briefCategoryDetail = briefCategoryDetail;
		this.gstPercentage = gstPercentage;
	}

	public int getSubcategoryId() {
		return subcategoryId;
	}

	public void setSubcategoryId(int subcategoryId) {
		this.subcategoryId = subcategoryId;
	}

	public String getSubCategoryName() {
		return subCategoryName;
	}

	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public String getBriefCategoryDetail() {
		return briefCategoryDetail;
	}

	public void setBriefCategoryDetail(String briefCategoryDetail) {
		this.briefCategoryDetail = briefCategoryDetail;
	}

	public Double getGstPercentage() {
		return gstPercentage;
	}

	public void setGstPercentage(Double gstPercentage) {
		this.gstPercentage = gstPercentage;
	}

	@Override
	public String toString() {
		return "SubCategory [subcategoryId=" + subcategoryId + ", subCategoryName=" + subCategoryName + ", category="
				+ category + ", briefCategoryDetail=" + briefCategoryDetail + ", gstPercentage=" + gstPercentage + "]";
	}

}
