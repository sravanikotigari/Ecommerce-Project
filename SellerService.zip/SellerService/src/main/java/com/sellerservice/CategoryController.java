package com.sellerservice;

public class CategoryController {

}
